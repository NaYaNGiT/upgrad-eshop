// src/pages/AddProductPage.js

import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button } from '@mui/material';

const AddProductPage = () => {
  const [productName, setProductName] = useState('');

  const handleAddProduct = async () => {
    try {
      await axios.post('https://dev-project-ecommerce.upgrad.dev/api/products', {
        name: productName,
      });
      // Handle success, e.g., redirect or show message
    } catch (error) {
      console.error("Error adding product:", error);
    }
  };

  return (
    <div>
      <TextField
        label="Product Name"
        onChange={(e) => setProductName(e.target.value)}
      />
      <Button onClick={handleAddProduct}>Add Product</Button>
    </div>
  );
};

export default AddProductPage;
