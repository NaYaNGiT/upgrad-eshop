// src/pages/SignUpPage.js

import React, { useState } from 'react';
import axios from 'axios';
import { TextField, Button } from '@mui/material';
import { useHistory } from 'react-router-dom';

const SignUpPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleSignUp = async () => {
    try {
      await axios.post('https://dev-project-ecommerce.upgrad.dev/api/users', {
        email,
        password,
      });
      history.push('/login');
    } catch (error) {
      console.error("Signup failed:", error);
    }
  };

  return (
    <div>
      <TextField label="Email" onChange={(e) => setEmail(e.target.value)} />
      <TextField type="password" label="Password" onChange={(e) => setPassword(e.target.value)} />
      <Button onClick={handleSignUp}>Sign Up</Button>
    </div>
  );
};

export default SignUpPage;
