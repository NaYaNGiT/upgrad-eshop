// src/App.js

import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import NavBar from './components/NavBar';
import LoginPage from './pages/LoginPage'; // Create this component
import SignUpPage from './pages/SignUpPage'; // Create this component
import ProductsPage from './pages/ProductsPage'; // Create this component
import AddProductPage from './pages/AddProductPage'; // Create this component

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // Determine if user is admin

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    // Additional logout logic (like clearing tokens)
  };

  return (
    <Router>
      <NavBar isLoggedIn={isLoggedIn} isAdmin={isAdmin} onLogout={handleLogout} />
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/signup" component={SignUpPage} />
        <Route path="/products" component={ProductsPage} />
        <Route path="/add-product" component={AddProductPage} />
        <Route path="/" exact component={ProductsPage} />
      </Switch>
    </Router>
  );
};

export default App;
