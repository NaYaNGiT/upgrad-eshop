// src/components/NavBar.js

import React from 'react';
import { AppBar, Toolbar, Typography, Button, InputBase } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useHistory } from 'react-router-dom';

const NavBar = ({ isLoggedIn, isAdmin, onLogout }) => {
  const history = useHistory();

  const handleSearch = (event) => {
    // Handle product search here (e.g., call API)
    const searchTerm = event.target.value;
    // Call the API with the search term
    console.log("Searching for:", searchTerm);
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <ShoppingCartIcon />
        <Typography variant="h6" style={{ flexGrow: 1 }}>
          upGrad Eshop
        </Typography>
        {isLoggedIn ? (
          <>
            <InputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
              onChange={handleSearch}
            />
            <Button color="inherit" onClick={() => history.push('/')}>Home</Button>
            <Button color="inherit" onClick={onLogout}>Logout</Button>
            {isAdmin && (
              <Button color="inherit" onClick={() => history.push('/add-product')}>Add Products</Button>
            )}
          </>
        ) : (
          <>
            <Button color="inherit" onClick={() => history.push('/login')}>Login</Button>
            <Button color="inherit" onClick={() => history.push('/signup')}>Sign Up</Button>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
